package com.seveinph.mindvalley_andynieves_android_test;

/**
 * Created by andi on 8/5/2016.
 */
public class Config {
    public String uri = "http://pastebin.com/raw/wgkJgazE";

}
