package com.seveinph.mindvalley_andynieves_android_test;

import android.graphics.drawable.Drawable;

/**
 * Created by andi on 8/5/2016.
 */
public class PinInfo {
    protected String id;
    protected String created_at;
    protected String width;
    protected String height;
    protected String color;
    protected int likes;
    protected Boolean liked_by_user;

    protected String user_id;
    protected String user_username;
    protected String user_name;
    protected String user_profile_img_small;
    protected String user_profile_img_medium;
    protected String user_profile_img_large;

    protected String url;
    protected String urls[];
    protected int categories;
    protected String links[];

    protected String download;
}
